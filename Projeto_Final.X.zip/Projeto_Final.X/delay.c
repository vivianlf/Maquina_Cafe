
void atraso(unsigned char N) {
    volatile unsigned char j, k, i, h;
    for (h = 0; h < N; h++)
        for (i = 0; i < 100; i++)
            for (j = 0; j < 41; j++) {
                for (k = 0; k < 3; k++);
            }
}