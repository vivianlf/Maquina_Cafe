/* 
 * File:   delay.h
 * Author: Daniel ferreira Lara
 *
 * Created on 5 de Outubro de 2021, 09:32
 */

#ifndef DELAY_H
#define	DELAY_H
void atraso(unsigned char);
#endif

